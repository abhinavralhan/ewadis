package Domain Model.olat;

public class Folder extends Entry {

}
