package Domain Model.olat;

import Programming Language Types.java.lang.String;

public class Person {

	private String firstName;

	private String lastName;

	private String email;

}
