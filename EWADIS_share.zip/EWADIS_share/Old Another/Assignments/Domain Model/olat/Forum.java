package Domain Model.olat;

import Programming Language Types.java.lang.String;

public class Forum {

	private String title;

	private String description;

}
