package Domain Model.olat;

import Programming Language Types.java.lang.String;

public class Group {

	private String name;

}
