package Domain Model.olat;

import Programming Language Types.java.lang.String;

public class File extends Entry {

	private String location;

	private int size;

}
