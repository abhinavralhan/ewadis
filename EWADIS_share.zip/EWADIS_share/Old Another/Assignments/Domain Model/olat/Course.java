package Domain Model.olat;

import Programming Language Types.java.lang.String;

public class Course {

	private String name;

	private String description;

}
