package Domain Model.olat;

import Programming Language Types.java.lang.String;
import Programming Language Types.java.util.Date;

public abstract class Entry {

	private String name;

	private Date lastModified;

}
