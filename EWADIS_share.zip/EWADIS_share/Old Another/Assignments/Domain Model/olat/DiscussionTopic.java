package Domain Model.olat;

import Programming Language Types.java.lang.String;
import Programming Language Types.java.util.Date;

public class DiscussionTopic {

	private String title;

	private String content;

	private Date lastModified;

}
